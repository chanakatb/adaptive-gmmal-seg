# Standard library imports
import os
import sys
from datetime import datetime
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# Third-party imports
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau
from tqdm import tqdm
import albumentations as A
from albumentations.pytorch import ToTensorV2
import pytz

# Local application imports
from src.model import UNET
from utils.utils import (
    get_loaders_with_augmentation,
    data_loader_for_fully_supervised_learning,
    Config,
    inspect_pixel_value_range,
    #save_predictions_as_imgs,
    save_fss_predictions_images,
    load_trained_model,
    calculate_dice_per_image,
    print_current_lr,
    check_dataloader_sizes,
    review_batch,
)

from loss_function import CombinedLoss

""" Training Hyperparameters """
LEARNING_RATE = 1e-4
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE = 16
START_EPOCH = 1
NUM_EPOCHS = 100
NUM_WORKERS = 4
IMAGE_HEIGHT = 256 
IMAGE_WIDTH = 256  
PIN_MEMORY = True

""" Early Stopping Conditions """
EARLY_STOPPING_EPOCHES = 20
EXPECTED_BEST_LOSS = 0.05

""" Load Pre-trained Model"""
LOAD_TRAINED_MODEL = False
PATH_TO_TRAINED_MODEL = None

""" Load Dataset"""
TRAIN_IMG_DIR = "../ISIC_2017_dataset/data/train_images/"
TRAIN_MASK_DIR = "../ISIC_2017_dataset/data/train_masks/" 
VAL_IMG_DIR = "../ISIC_2017_dataset/data/val_images/"
VAL_MASK_DIR = "../ISIC_2017_dataset/data/val_masks/" 
TEST_IMG_DIR = "../ISIC_2017_dataset/data/test_images/"
TEST_MASK_DIR = "../ISIC_2017_dataset/data/test_masks/" 

""" Saving Directory"""
MODEL_DIRECTORY = "results/fully_supervised_trained_model"
IMAGE_VAL_DIRECTORY = "results/fully_supervised_validation_images"
IMAGE_TEST_DIRECTORY = "results/fully_supervised_test_images"

""" Training """
def train_fn(loader, model, optimizer, loss_fn, device):
    model.train()
    total_loss = 0
    total_dice = 0
    num_images = 0
    bottlenecks = []  # Collect bottlenecks across batches
    loop = tqdm(loader)
    for batch_idx, (data, targets) in enumerate(loop):
        data = data.to(device) # [-1,1]
        targets = targets.float().to(device) # {0,1}

        # forward
        predictions, bottleneck = model(data)
        predictions = torch.sigmoid(predictions)  # Convert logits to probabilities [0,1]        
        loss = loss_fn(predictions, targets) # [0,1], {0,1}

        # After calculating loss, convert to binary for metrics
        predictions = (predictions > 0.5).float()  # Convert to binary {0, 1} for metrics/visualization

        # backward - standard approach without scaler
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Calculate metrics
        total_loss += loss.item()
        preds = predictions.float()
        total_dice += calculate_dice_per_image(preds, targets).sum() # {0,1}, {0,1}
        num_images += targets.size(0)

        
        # update tqdm loop
        loop.set_postfix(loss=loss.item())        

        # Free GPU memory
        del data, targets, predictions, bottleneck
        torch.cuda.empty_cache()

    avg_loss = total_loss / len(loader)
    avg_dice = total_dice / num_images  # Mean Dice per image
    return avg_loss, avg_dice, bottlenecks

""" Validation """
def validate_fn(loader, model, loss_fn, device):
    model.eval()
    total_loss = 0
    total_dice = 0
    num_images = 0
    loop = tqdm(loader)  # Add progress bar for validation
    with torch.no_grad():
        for idx, (data, targets) in enumerate(loop):
            data = data.to(device)
            targets = targets.float().to(device)  # {0,1}
            
            predictions, bottleneck = model(data) 
            predictions = torch.sigmoid(predictions)  # Convert logits to probabilities [0, 1] 
            loss = loss_fn(predictions, targets) # [0,1], {0,1}

            # After calculating loss, convert to binary for metrics
            predictions = (predictions > 0.5).float()  # Convert to binary {0, 1} for metrics/visualization

            # Calculate metrics
            total_loss += loss.item()
            preds = predictions.float()
            total_dice += calculate_dice_per_image(preds, targets).sum() # {0,1}, {0,1}
            num_images += targets.size(0)
            
            # Update progress bar
            loop.set_postfix(loss=loss.item())
            
            # Free GPU memory
            del data, targets, predictions, bottleneck
            torch.cuda.empty_cache()
    
    avg_loss = total_loss / len(loader)
    avg_dice = total_dice / num_images  # Mean Dice per image
    return avg_loss, avg_dice


""" Test Function """
def test_fn(loader, model, loss_fn, device):
    model.eval()
    total_loss = 0
    total_dice = 0
    num_images = 0
    loop = tqdm(loader)
    for batch_idx, (data, targets) in enumerate(loop):
        data = data.to(device) # [-1,1]
        targets = targets.float().to(device) # {0,1}

        # forward
        predictions, _ = model(data)
        predictions = torch.sigmoid(predictions)  # Convert logits to probabilities [0,1]        
        loss = loss_fn(predictions, targets) # [0,1], {0,1}

        # After calculating loss, convert to binary for metrics
        predictions = (predictions > 0.5).float()  # Convert to binary {0, 1} for metrics/visualization
       
        # Calculate metrics
        total_loss += loss.item()
        preds = predictions.float()
        total_dice += calculate_dice_per_image(preds, targets).sum() # {0,1}, {0,1}
        num_images += targets.size(0)
        
        # update tqdm loop
        loop.set_postfix(loss=loss.item())        

        # Free GPU memory
        del data, targets, predictions
        torch.cuda.empty_cache()

    avg_loss = total_loss / len(loader)
    avg_dice = total_dice / num_images  # Mean Dice per image
    return avg_loss, avg_dice

""" Main Function """
def main():
    torch.cuda.empty_cache()  # Optional: clear any GPU leftovers from earlier runs
    
    # Setup phase
    model_path, val_image_path, test_image_path = setup_directories()
    train_transform, val_transforms, test_transforms = create_transforms()
    config = setup_augmentation_config()
    
    # Model initialization
    model = UNET(in_channels=3, out_channels=1).to(DEVICE)
    # loss_fn =  nn.BCELoss()
    loss_fn = CombinedLoss(alpha=0.3, beta=0.5, gamma=0.2)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    scheduler = setup_scheduler(optimizer)
    
    # Data loading
    train_loader, val_loader, test_loader = load_and_review_data(
        train_transform, val_transforms, test_transforms, config
    )
    
    # Model loading if needed
    model, optimizer, scheduler, start_epoch = load_pretrained_model(model, optimizer, scheduler)
    
    # Training loop
    train_model(
        model, train_loader, val_loader, test_loader, optimizer, 
        scheduler, loss_fn, model_path,  val_image_path, test_image_path, start_epoch
    )


""" Setup Directories """
def setup_directories():
    """Create and return model directories for saving checkpoints"""
    timenow = datetime.strftime(datetime.now(pytz.timezone('America/New_York')), '%Y-%m-%d_%H-%M-%S')
    run_name = f"{timenow}_fully_supervised"  # e.g. 2026-10-31_15-40-07_fully_supervised
    model_path = os.path.join(MODEL_DIRECTORY, run_name)
    val_image_path = os.path.join(IMAGE_VAL_DIRECTORY, run_name)
    test_image_path = os.path.join(IMAGE_TEST_DIRECTORY, run_name)
    os.makedirs(model_path, exist_ok=True)
    os.makedirs(val_image_path, exist_ok=True)
    os.makedirs(test_image_path, exist_ok=True)
    print("The model will be saved at:", model_path)
    print("The validation images will be saved at:", val_image_path)
    print("The test images will be saved at:", test_image_path)
    return model_path, val_image_path, test_image_path

""" Transformations """
def create_transforms():
    """Create and return training and validation transforms"""
    train_transform = A.Compose([
        A.Resize(height=IMAGE_HEIGHT, width=IMAGE_WIDTH),
        A.Rotate(limit=35, p=1.0),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.1),
        ToTensorV2(),
    ])
    
    val_transforms = A.Compose([
        A.Resize(height=IMAGE_HEIGHT, width=IMAGE_WIDTH),
        ToTensorV2(),
    ])

    test_transforms = A.Compose([
        A.Resize(height=IMAGE_HEIGHT, width=IMAGE_WIDTH),
        ToTensorV2(),
    ])
    
    return train_transform, val_transforms, test_transforms

""" Augmentations """
def setup_augmentation_config():
    """Set up configuration for self-supervised augmentations"""
    return Config(
        flip_rate=0.5,
        local_rate=0.4,
        nonlinear_rate=0.6, 
        paint_rate=0.7,
        inpaint_rate=0.5
    )


""" Scheduler """
def setup_scheduler(optimizer):
    """Set up learning rate scheduler"""
    scheduler = ReduceLROnPlateau(
        optimizer, 
        mode='min', 
        factor=0.5, 
        patience=5
    )
    print_current_lr(scheduler)
    return scheduler


""" Load and Review Data """
def load_and_review_data(train_transform, val_transforms, test_transforms, config):
    """Load and review training and validation data"""
    train_loader, val_loader, test_loader = data_loader_for_fully_supervised_learning(
        TRAIN_IMG_DIR,
        TRAIN_MASK_DIR,
        VAL_IMG_DIR,
        VAL_MASK_DIR,
        TEST_IMG_DIR,
        TEST_MASK_DIR,
        BATCH_SIZE,
        train_transform,
        val_transforms, # no augmentation. only resizing
        test_transforms, # no augmentation. only resizing
        num_workers=NUM_WORKERS,
        pin_memory=PIN_MEMORY,
        config=config,
        shuffle_train=True # shuffle training dataset
    )
    print("train_loader and val_loarder is completed. \n")
    
    # # Pixel value range
    # inspect_pixel_value_range(train_loader, "Train Loader")
    # inspect_pixel_value_range(val_loader, "Validation Loader")
    # inspect_pixel_value_range(test_loader, "Test Loader")
    
    # # Review training and validation data
    # print("\nReviewing training data")
    # check_dataloader_sizes(train_loader)
    # review_batch(train_loader, 'training data')
    # print("\nReviewing validation data")
    # check_dataloader_sizes(val_loader)
    # review_batch(val_loader, 'validation data')
    # print("\nReviewing test data")
    # check_dataloader_sizes(test_loader)
    # review_batch(test_loader, 'test data')
    
    return train_loader, val_loader, test_loader


""" Load Pre-trained Model"""
def load_pretrained_model(model, optimizer, scheduler):
    """Load pre-trained model if specified or return default start epoch"""
    if LOAD_TRAINED_MODEL and PATH_TO_TRAINED_MODEL:
        print("\nPre-train model loaded. MODEL_PATH:", PATH_TO_TRAINED_MODEL, "\n")
        model, optimizer, scheduler, start_epoch = load_trained_model(
            model, optimizer, scheduler, PATH_TO_TRAINED_MODEL
        )
        return model, optimizer, scheduler, start_epoch
    else:
        print("\nNo pre-trained model loaded. Starting from scratch.\n")
        return model, optimizer, scheduler, START_EPOCH


""" Func for Train Model """
def train_model(model, train_loader, val_loader, test_loader, optimizer, scheduler, loss_fn, model_path, val_image_path, test_image_path, start_epoch):
    """Execute the main training loop"""
    best_dice = float('-inf')  # Checkpoint selection metric
    best_loss = float('inf')   # Only used for the EXPECTED_BEST_LOSS early stopping condition
    num_epoch_no_improvement = 0
    
    # Clear memory before training
    sys.stdout.flush()
    torch.cuda.empty_cache()

    # Dictionary to store train and validation results across iterations
    train_results = {}

    # Run test on each epoch
    test_results = {}
    
    print('start_epoch: ', start_epoch)
    
    for epoch in range(start_epoch, NUM_EPOCHS + 1):
        print(f"\nTrain: Epoch {epoch}/{NUM_EPOCHS}")
        model = model.to(DEVICE)
        
        # Training and validation for this epoch
        print("Train ...")
        train_loss, train_dice, features_space = train_fn(train_loader, model, optimizer, loss_fn, DEVICE)
        print("Validation ...")
        valid_loss, valid_dice = validate_fn(val_loader, model, loss_fn, DEVICE)
        
        # Log metrics
        print(f"Train Loss: {train_loss:.4f}, Train Dice: {train_dice:.4f}")
        print(f"Valid Loss: {valid_loss:.4f}, Valid Dice: {valid_dice:.4f}")

        # Create a unique key for each iteration-epoch combination
        train_result_key = f"{epoch}"
        
        # Store results
        train_results[train_result_key] = {
            'epoch': epoch,
            'sample_size': 2000,
            'current_learning_rate': optimizer.param_groups[0]['lr'],
            'train_loss': f"{train_loss:.5f}",
            'train_dice': f"{train_dice.item():.5f}",
            'valid_loss': f"{valid_loss:.5f}",
            'valid_dice': f"{valid_dice.item():.5f}"
        }
        
        # Save results to CSV
        print("Saving training results to .csv")
        results_df = pd.DataFrame.from_dict(train_results, orient='index')
        results_df.to_csv(os.path.join(model_path, 'train_results.csv'))

        # Update learning rate
        scheduler.step(valid_loss)
        print_current_lr(scheduler)
        
        best_loss = min(best_loss, valid_loss)

        # Save model if validation Dice improved
        if float(valid_dice) > best_dice:
            handle_improved_model(model, optimizer, scheduler, epoch, float(valid_dice), best_dice, model_path)

            # Save sample predictions
            save_fss_predictions_images(val_loader, model, folder=val_image_path, device=DEVICE)

            best_dice = float(valid_dice)
            num_epoch_no_improvement = 0
        else:
            num_epoch_no_improvement += 1
            print(f"Validation Dice does not increase from {best_dice:.4f}, "
                  f"num_epoch_no_improvement {num_epoch_no_improvement}")
            
        # Check early stopping conditions
        if check_early_stopping(num_epoch_no_improvement, best_loss):
            break
    
        # After training is complete, run testing on the best model
        print("\n--- Testing Best Model After Training ---")
        # Load the best model for  testing
        best_model = UNET(in_channels=3, out_channels=1).to(DEVICE)
        best_checkpoint = torch.load(os.path.join(model_path, "fully_supervised_learning.pt"), map_location=DEVICE)
        best_model.load_state_dict(best_checkpoint['state_dict'])
        
        # Run test for each epoch where we have training data
        print(f"\n--- Running test evaluation for epoch {epoch} ---")
        test_loss, test_dice = test_fn(test_loader, best_model, loss_fn, DEVICE)
        
        # Store results
        # Create a unique key for each epoch 
        test_result_key = f"{epoch}"
        
        # Store results
        test_results[test_result_key] = {
            'iteration': epoch,
            'current_learning_rate': train_results[str(epoch)]['current_learning_rate'],
            'test_loss': f"{test_loss:.5f}",
            'test_dice': f"{test_dice.item():.5f}"
        }
        
        # Save test results
        results_df = pd.DataFrame.from_dict(test_results, orient='index')
        results_df.to_csv(os.path.join(model_path, 'test_results.csv'))
        
        # Save images of predictions on test set
        save_fss_predictions_images(test_loader, best_model, folder=test_image_path, device=DEVICE)                
        print("Testing completed.")

        # Clean up after epoch
        sys.stdout.flush()
        torch.cuda.empty_cache()

""" Func for Improved Model """
def handle_improved_model(model, optimizer, scheduler, epoch, valid_dice, best_dice, model_path):
    """Save model when validation Dice improves"""
    print(f"Validation Dice increases from {best_dice:.4f} to {valid_dice:.4f}")
    
    # Move model to CPU for saving
    model = model.cpu()
    
    # Save model state
    save_dict = {
        'epoch': epoch,
        'state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict()
    }
    save_path = os.path.join(model_path, "fully_supervised_learning.pt")
    torch.save(save_dict, save_path)
    print(f"Saving model {save_path}")
    
    # Move model back to GPU
    model = model.to(DEVICE)


""" Func for Early Stopping Conditions """
def check_early_stopping(num_epoch_no_improvement, best_loss):
    """Check if early stopping criteria are met"""
    if num_epoch_no_improvement >= EARLY_STOPPING_EPOCHES or best_loss <= EXPECTED_BEST_LOSS:
        if num_epoch_no_improvement >= EARLY_STOPPING_EPOCHES:
            print(f"Early stopping triggered: No improvement for {EARLY_STOPPING_EPOCHES} epochs")
        else:
            print(f"Early stopping triggered: Best loss of {best_loss:.4f} reached")
        return True
    return False

if __name__ == "__main__":
    main()